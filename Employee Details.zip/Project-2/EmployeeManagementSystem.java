import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EmployeeManagementSystem extends JFrame {

    public EmployeeManagementSystem() {
        setTitle("Employee Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create menus
        JMenu employeeMenu = new JMenu("Employee");
        JMenu payrollMenu = new JMenu("Payroll");
        JMenu attendanceMenu = new JMenu("Attendance");

        // Create menu items
        JMenuItem addEmployee = new JMenuItem("Add Employee");
        JMenuItem viewEmployees = new JMenuItem("View Employees");
        JMenuItem addPayroll = new JMenuItem("Add Payroll");
        JMenuItem viewPayrolls = new JMenuItem("View Payrolls");
        JMenuItem addAttendance = new JMenuItem("Add Attendance");
        JMenuItem viewAttendance = new JMenuItem("View Attendance");

        // Add action listeners
        addEmployee.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open add employee form
                new AddEmployeeForm().setVisible(true);
            }
        });

        viewEmployees.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open view employees form
                new ViewEmployeesForm().setVisible(true);
            }
        });

        addPayroll.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open add payroll form
                new AddPayrollForm().setVisible(true);
            }
        });

        viewPayrolls.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open view payrolls form
                new ViewPayrollsForm().setVisible(true);
            }
        });

        addAttendance.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open add attendance form
                new AddAttendanceForm().setVisible(true);
            }
        });

        viewAttendance.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open view attendance form
                new ViewAttendanceForm().setVisible(true);
            }
        });

        // Add menu items to menus
        employeeMenu.add(addEmployee);
        employeeMenu.add(viewEmployees);
        payrollMenu.add(addPayroll);
        payrollMenu.add(viewPayrolls);
        attendanceMenu.add(addAttendance);
        attendanceMenu.add(viewAttendance);

        // Add menus to menu bar
        menuBar.add(employeeMenu);
        menuBar.add(payrollMenu);
        menuBar.add(attendanceMenu);

        // Set the menu bar
        setJMenuBar(menuBar);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EmployeeManagementSystem().setVisible(true);
            }
        });
    }
}
