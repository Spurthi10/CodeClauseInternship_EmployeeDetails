import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdateEmployeeForm extends JFrame {

    private JTextField employeeIdField;
    private JTextField nameField;
    private JTextField departmentField;
    private JTextField positionField;
    private JTextField salaryField;
    private JTextField hireDateField;

    public UpdateEmployeeForm() {
        setTitle("Update Employee");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(7, 2));

        panel.add(new JLabel("Employee ID:"));
        employeeIdField = new JTextField();
        panel.add(employeeIdField);

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Department:"));
        departmentField = new JTextField();
        panel.add(departmentField);

        panel.add(new JLabel("Position:"));
        positionField = new JTextField();
        panel.add(positionField);

        panel.add(new JLabel("Salary:"));
        salaryField = new JTextField();
        panel.add(salaryField);

        panel.add(new JLabel("Hire Date (YYYY-MM-DD):"));
        hireDateField = new JTextField();
        panel.add(hireDateField);

        JButton updateButton = new JButton("Update Employee");
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateEmployee();
            }
        });

        panel.add(updateButton);

        add(panel);
    }

    private void updateEmployee() {
        int employeeId = Integer.parseInt(employeeIdField.getText());
        String name = nameField.getText();
        String department = departmentField.getText();
        String position = positionField.getText();
        double salary = Double.parseDouble(salaryField.getText());
        String hireDate = hireDateField.getText();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "username", "password");
            String sql = "UPDATE employees SET name = ?, department = ?, position = ?, salary = ?, hire_date = TO_DATE(?, 'YYYY-MM-DD') WHERE employee_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, department);
            pstmt.setString(3, position);
            pstmt.setDouble(4, salary);
            pstmt.setString(5, hireDate);
            pstmt.setInt(6, employeeId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Employee updated successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Employee not found.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating employee.");
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
