import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewPayrollsForm extends JFrame {

    private JTable payrollTable;

    public ViewPayrollsForm() {
        setTitle("View Payrolls");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create table model
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Payroll ID");
        tableModel.addColumn("Employee ID");
        tableModel.addColumn("Base Salary");
        tableModel.addColumn("Bonus");
        tableModel.addColumn("Deductions");
        tableModel.addColumn("Net Salary");

        // Create table
        payrollTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(payrollTable);
        add(scrollPane, BorderLayout.CENTER);

        // Load payrolls from database
        loadPayrolls(tableModel);
    }

    private void loadPayrolls(DefaultTableModel tableModel) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "username", "password");
            String sql = "SELECT * FROM payroll";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int payrollId = rs.getInt("payroll_id");
                int employeeId = rs.getInt("employee_id");
                double baseSalary = rs.getDouble("base_salary");
                double bonus = rs.getDouble("bonus");
                double deductions = rs.getDouble("deductions");
                double netSalary = rs.getDouble("net_salary");

                tableModel.addRow(new Object[]{payrollId, employeeId, baseSalary, bonus, deductions, netSalary});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading payrolls.");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
