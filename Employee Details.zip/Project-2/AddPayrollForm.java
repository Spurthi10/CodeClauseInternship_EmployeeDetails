import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddPayrollForm extends JFrame {

    private JTextField employeeIdField;
    private JTextField baseSalaryField;
    private JTextField bonusField;
    private JTextField deductionsField;

    public AddPayrollForm() {
        setTitle("Add Payroll");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(5, 2));

        panel.add(new JLabel("Employee ID:"));
        employeeIdField = new JTextField();
        panel.add(employeeIdField);

        panel.add(new JLabel("Base Salary:"));
        baseSalaryField = new JTextField();
        panel.add(baseSalaryField);

        panel.add(new JLabel("Bonus:"));
        bonusField = new JTextField();
        panel.add(bonusField);

        panel.add(new JLabel("Deductions:"));
        deductionsField = new JTextField();
        panel.add(deductionsField);

        JButton addButton = new JButton("Add Payroll");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPayroll();
            }
        });

        panel.add(addButton);

        add(panel);
    }

    private void addPayroll() {
        int employeeId = Integer.parseInt(employeeIdField.getText());
        double baseSalary = Double.parseDouble(baseSalaryField.getText());
        double bonus = Double.parseDouble(bonusField.getText());
        double deductions = Double.parseDouble(deductionsField.getText());
        double netSalary = baseSalary + bonus - deductions;

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "username", "password");
            String sql = "INSERT INTO payroll (payroll_id, employee_id, base_salary, bonus, deductions, net_salary) VALUES (payroll_seq.NEXTVAL, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeId);
            pstmt.setDouble(2, baseSalary);
            pstmt.setDouble(3, bonus);
            pstmt.setDouble(4, deductions);
            pstmt.setDouble(5, netSalary);

            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Payroll added successfully.");
            dispose();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding payroll.");
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
