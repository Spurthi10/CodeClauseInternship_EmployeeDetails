import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class DeletePayrollForm extends JFrame {

    private JTextField payrollIdField;

    public DeletePayrollForm() {
        setTitle("Delete Payroll");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2));

        panel.add(new JLabel("Payroll ID:"));
        payrollIdField = new JTextField();
        panel.add(payrollIdField);

        JButton deleteButton = new JButton("Delete Payroll");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletePayroll();
           
