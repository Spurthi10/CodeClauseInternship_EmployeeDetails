import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class UpdatePayrollForm extends JFrame {

    private JTextField payrollIdField;
    private JTextField employeeIdField;
    private JTextField baseSalaryField;
    private JTextField bonusField;
    private JTextField deductionsField;

    public UpdatePayrollForm() {
        setTitle("Update Payroll");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(6, 2));

        panel.add(new JLabel("Payroll ID:"));
        payrollIdField = new JTextField();
        panel.add(payrollIdField);

        panel.add(new JLabel("Employee ID:"));
        employeeIdField = new JTextField();
        panel.add(employeeIdField);

        panel.add(new JLabel("Base Salary:"));
        baseSalaryField = new JTextField();
        panel.add(baseSalaryField);

        panel.add(new JLabel("Bonus:"));
        bonusField = new JTextField();
        panel.add(bonusField);

        panel.add(new JLabel("Deductions:"));
        deductionsField = new JTextField();
        panel.add(deductionsField);

        JButton updateButton = new JButton("Update Payroll");
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updatePayroll();
            }
        });

        panel.add(updateButton);

        add(panel);
    }

    private void updatePayroll() {
        int payrollId = Integer.parseInt(payrollIdField.getText());
        int employeeId = Integer.parseInt(employeeIdField.getText());
        double baseSalary = Double.parseDouble(baseSalaryField.getText());
        double bonus = Double.parseDouble(bonusField.getText());
        double deductions = Double.parseDouble(deductionsField.getText());
        double netSalary = baseSalary + bonus - deductions;

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "username", "password");
            String sql = "UPDATE payroll SET employee_id = ?, base_salary = ?, bonus = ?, deductions = ?, net_salary = ? WHERE payroll_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeId);
            pstmt.setDouble(2, baseSalary);
            pstmt.setDouble(3, bonus);
            pstmt.setDouble(4, deductions);
            pstmt.setDouble(5, netSalary);
            pstmt.setInt(6, payrollId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Payroll updated successfully.");
            } else {
                JOptionPane.showMessageDialog(this, "Payroll record not found.");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating payroll.");
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
