import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddAttendanceForm extends JFrame {

    private JTextField employeeIdField;
    private JTextField attendanceDateField;
    private JComboBox<String> statusComboBox;

    public AddAttendanceForm() {
        setTitle("Add Attendance");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 2));

        panel.add(new JLabel("Employee ID:"));
        employeeIdField = new JTextField();
        panel.add(employeeIdField);

        panel.add(new JLabel("Attendance Date (YYYY-MM-DD):"));
        attendanceDateField = new JTextField();
        panel.add(attendanceDateField);

        panel.add(new JLabel("Status:"));
        statusComboBox = new JComboBox<>(new String[]{"Present", "Absent"});
        panel.add(statusComboBox);

        JButton addButton = new JButton("Add Attendance");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addAttendance();
            }
        });

        panel.add(addButton);

        add(panel);
    }

    private void addAttendance() {
        int employeeId = Integer.parseInt(employeeIdField.getText());
        String attendanceDate = attendanceDateField.getText();
        String status = (String) statusComboBox.getSelectedItem();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "username", "password");
            String sql = "INSERT INTO attendance (attendance_id, employee_id, attendance_date, status) VALUES (attendance_seq.NEXTVAL, ?, TO_DATE(?, 'YYYY-MM-DD'), ?)";
            pstmt = conn.prepare
