-- Create table for employees
CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    department VARCHAR2(50),
    position VARCHAR2(50),
    salary NUMBER,
    hire_date DATE
);

-- Create table for payroll
CREATE TABLE payroll (
    payroll_id NUMBER PRIMARY KEY,
    employee_id NUMBER REFERENCES employees(employee_id),
    base_salary NUMBER,
    bonus NUMBER,
    deductions NUMBER,
    net_salary NUMBER
);

-- Create table for attendance
CREATE TABLE attendance (
    attendance_id NUMBER PRIMARY KEY,
    employee_id NUMBER REFERENCES employees(employee_id),
    attendance_date DATE,
    status VARCHAR2(10) -- Present or Absent
);
